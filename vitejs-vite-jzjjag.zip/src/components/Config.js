// config.js
module.exports = {
  key: '9063a3e3bd8e02ae19b2da7928eb91b1', // Replace with your API key if needed
  base: 'https://api.openweathermap.org/data/2.5/',
};
